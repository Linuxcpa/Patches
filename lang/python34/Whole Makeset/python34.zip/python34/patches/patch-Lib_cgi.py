$NetBSD$

--- Lib/cgi.py.orig	2014-05-19 05:19:37.000000000 +0000
+++ Lib/cgi.py
@@ -1,4 +1,4 @@
-#! /usr/local/bin/python
+#!/boot/home/pkgsrc/pkgsrc/lang/python34/work/Python-3.4.1
 
 # NOTE: the above "/usr/local/bin/python" is NOT a mistake.  It is
 # intentionally NOT "/usr/bin/env python".  On many systems
